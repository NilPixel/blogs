//
//  MJDefineModel.m
//  JsonModelDemo
//
//  Created by Apple on 16/10/21.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import "MJDefineModel.h"

@implementation MJDefineModel

- (id)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property
{
//    if ([property.name isEqualToString:@"testUrl"]) {
//        if (oldValue == nil) return @"";
//    } else
        if (property.type.typeClass == [NSDate class]) {
        NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
        fmt.dateFormat = @"yyyy MM dd HH:mm:ss";
        return [fmt dateFromString:oldValue];
    }
    
    return oldValue;
}

@end
