//
//  MJKeyOrderModel.m
//  JsonModelDemo
//
//  Created by Apple on 16/10/18.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import "MJKeyOrderModel.h"

@implementation MJKeyOrderModel

//左边key值  右边 接口返回值
+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{
             @"orderId" : @"order_id",
             @"productName": @"order_details.name",
             @"price": @"order_details.price.usd",
             };
}

@end



