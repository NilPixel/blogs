//
//  MJNewOrderModel.m
//  JsonModelDemo
//
//  Created by Apple on 16/10/18.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import "MJNewOrderModel.h"

@implementation MJNewOrderModel


+ (NSDictionary *)objectClassInArray{
    return @{@"products" : [MJProducts class]};
}

@end

@implementation MJProducts

@end


