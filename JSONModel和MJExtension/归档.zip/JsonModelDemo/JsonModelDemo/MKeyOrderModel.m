//
//  MKeyOrderModel.m
//  JsonModelDemo
//
//  Created by Apple on 16/9/28.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import "MKeyOrderModel.h"

@implementation MKeyOrderModel

+(JSONKeyMapper*)keyMapper
{
    return [[JSONKeyMapper alloc] initWithModelToJSONDictionary:@{
                                                                  @"orderId": @"order_id",
                                                                  @"productName": @"order_details.name",
                                                                  @"price": @"order_details.price.usd"
                                                                  }];
}

@end
