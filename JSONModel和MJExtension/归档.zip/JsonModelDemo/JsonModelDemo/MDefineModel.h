//
//  MDefineModel.h
//  JsonModelDemo
//
//  Created by Apple on 16/9/28.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import "JSONModel.h"

@interface MDefineModel : JSONModel

@property (nonatomic, strong) NSDate *date;

@property (nonatomic, strong) NSURL *testUrl;

@end
