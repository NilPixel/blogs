//
//  MUnderLineModel.h
//  JsonModelDemo
//
//  Created by Apple on 16/9/28.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import "JSONModel.h"

@interface MUnderLineModel : JSONModel

@property (assign, nonatomic) int orderId;
@property (assign, nonatomic) float orderPrice;
@property (strong, nonatomic) NSString* orderProduct;

@end
