//
//  MJCoutryModel.m
//  JsonModelDemo
//
//  Created by Apple on 16/10/18.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import "MJCoutryModel.h"

@implementation MJCoutryModel

//- (id)initWithCoder:(NSCoder *)decoder
//{
//    if (self = [super init]) {
//        [self mj_decode:decoder];
//    }
//    return self;
//}
//
//- (void)encodeWithCoder:(NSCoder *)encoder
//{ 
//    [self mj_encode:encoder];
//}

@end
