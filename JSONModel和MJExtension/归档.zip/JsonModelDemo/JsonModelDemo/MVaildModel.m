//
//  MVaildModel.m
//  JsonModelDemo
//
//  Created by Apple on 16/9/28.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import "MVaildModel.h"

@implementation MVaildModel

- (BOOL)validate:(NSError *__autoreleasing *)error {
    BOOL valid = [super validate:error];
    
    if (self.countryId.length < 1) {
        *error = [NSError errorWithDomain:@"me.mycompany.com" code:1 userInfo:nil];
        valid = NO;
    }
    
    return valid;
}


@end
