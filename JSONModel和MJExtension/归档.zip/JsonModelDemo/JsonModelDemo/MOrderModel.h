//
//  MOrderModel.h
//  JsonModelDemo
//
//  Created by Apple on 16/9/28.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import "JSONModel.h"

//@class Product1;
@interface MOrderModel : JSONModel

//@property (nonatomic, copy) NSString *total_price;
//
//@property (nonatomic, assign) NSInteger order_id;
//
//@property (nonatomic, strong) Product1 *product;
//
//@end
//
//@interface Product1 : JSONModel
//
//@property (nonatomic, copy) NSString *productId;
//
//@property (nonatomic, copy) NSString *name;
//
//@property (nonatomic, assign) float price;

@end



