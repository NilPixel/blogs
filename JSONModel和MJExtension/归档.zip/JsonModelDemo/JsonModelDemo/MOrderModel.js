{
  "order_id": 104,
  "total_price": 13.45,
  "product" : {
    "productId": "123",
    "name": "Product name",
    "price": 12.95
  }
}