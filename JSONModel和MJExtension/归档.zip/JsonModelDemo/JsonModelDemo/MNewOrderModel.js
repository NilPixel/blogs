{
  "order_id": 104,
  "total_price": 103.56,
  "products" : [
    {
      "productId": "123",
      "name": "Product #1",
      "price": 12.56
    },
    {
      "productId": "137",
      "name": "Product #2",
      "price": 82.324
    }
  ]
}