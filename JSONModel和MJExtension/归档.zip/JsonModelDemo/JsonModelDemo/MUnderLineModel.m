//
//  MUnderLineModel.m
//  JsonModelDemo
//
//  Created by Apple on 16/9/28.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import "MUnderLineModel.h"

@implementation MUnderLineModel

+(JSONKeyMapper*)keyMapper
{
    //设置下划线自动转驼峰
    return [JSONKeyMapper mapperForSnakeCase];
}


@end
