//
//  MTestViewController.m
//  JsonModelDemo
//
//  Created by Apple on 16/9/28.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import "MTestViewController.h"
#import "MCountryModel.h"
#import "MOrderModel.h"
#import "MNewOrderModel.h"
#import "MKeyOrderModel.h"
#import "MUnderLineModel.h"
#import "MVaildModel.h"
#import "MDefineModel.h"
#import "JSONHTTPClient.h"


#import "MJCoutryModel.h"
#import "MJExtension.h"
#import "MJOrderModel.h"
#import "MJNewOrderModel.h"
#import "MJKeyOrderModel.h"
#import "MJDefineModel.h"

@interface MTestViewController ()

@end

@implementation MTestViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton *testButton = [[UIButton alloc]initWithFrame:CGRectMake(100, 100, 100, 100)];
    [testButton setTitle:@"点我" forState:UIControlStateNormal];
    [testButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    testButton.layer.borderWidth = 2;
    testButton.layer.borderColor = [UIColor yellowColor].CGColor;
    [testButton addTarget:self action:@selector(clickButton) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:testButton];
}

- (void)clickButton
{
    NSLog(@"点击按钮");
//    [JSONHTTPClient getJSONFromURLWithString:@"http://www.newtest.com" completion:^(id json, JSONModelError *err) {
//        NSLog(@"%@",json);
    //    }];
      NSLog(@"开始－－－－－－－－－－－－－－－－－－－开始");
//        命名自动匹配
//       [self getCountryModel];
        // 模型嵌套 (模型包含其他模型)
//        [self getMOrderModel];
    
        //模型集合
//        [self getMNewOrderModel];
        //key映射
//        [self getMKeyOrderModel];
        //设置下划线自动转驼峰
//        [self getMUnderLineModel];
        //自定义数据的转换
        [self getMDefineModel];
        //自定义JSON校验
//        [self getMVaildModel];
    NSLog(@"结束－－－－－－－－－－－－－－－－－－－结束");
}
//命名自动匹配
- (void)getCountryModel
{
    NSError* err = nil;
//    NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile:@"/JsonModelDemo/coutryModel.js"];
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"coutryModel" ofType:@"js"];
    NSData *data = [NSData dataWithContentsOfFile:filePath];
    id json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&err];
    
//    MCountryModel* country = [[MCountryModel alloc] initWithDictionary:json error:&err]; //s0.001
    
    MJCoutryModel *country = [MJCoutryModel mj_objectWithKeyValues:json]; //0.001
    
   //  NSData *archiverData = [NSKeyedArchiver archivedDataWithRootObject:country];
   // NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
   // [userDefaults setObject:archiverData forKey:@"MMDCountry"];
    
  //  NSData *unKeyData  = [userDefaults objectForKey:@"MMDCountry"];
  //  MJCoutryModel *country2 = [NSKeyedUnarchiver unarchiveObjectWithData:unKeyData];
//    country.dialCode = @"ert";
    NSLog(@"%@",country);
}
// 模型嵌套 (模型包含其他模型)
- (void)getMOrderModel
{
//    {
//        "order_id": 104,
//        "total_price": 13.45,
//        "product" : {
//            "id": "123",
//            "name": "Product name",
//            "price": 12.95
//        }
//    }
//    NSDictionary *product = [NSDictionary ]
    NSError* err = nil;
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"MOrderModel" ofType:@"js"];
    NSData *data = [NSData dataWithContentsOfFile:filePath];
    id json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&err];
    MOrderModel * country = [[MOrderModel alloc] initWithDictionary:json error:&err];//0.045
    
//    MJOrderModel *country = [MJOrderModel mj_objectWithKeyValues:json];//0.02
//    NSLog(@"%@",country);
}
//模型集合
- (void)getMNewOrderModel
{
//    {
//        "order_id": 104,
//        "total_price": 103.45,
//        "products" : [
//                      {
//                          "productId": "123",
//                          "name": "Product #1",
//                          "price": 12.95
//                      },
//                      {
//                          "productId": "137",
//                          "name": "Product #2",
//                          "price": 82.95
//                      }
//                      ]
//    }
    NSError* err = nil;
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"MNewOrderModel" ofType:@"js"];
    NSData *data = [NSData dataWithContentsOfFile:filePath];
    id json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&err];
    MNewOrderModel * country = [[MNewOrderModel alloc] initWithDictionary:json error:&err];//0.039 0.032 0.028 0.039
    
//    MJNewOrderModel *country = [MJNewOrderModel mj_objectWithKeyValues:json];//0.094  0.024 0.037 0.043
//    NSLog(@"%@",country);
}
//key映射
- (void)getMKeyOrderModel
{
//    {
//        "order_id": 104,
//        "order_details" :
//        {
//            "name": "Product#1",
//            "price": {
//                "usd": 12.95
//            }
//        }
//    }
    NSError* err = nil;
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"MKeyOrderModel" ofType:@"js"];
    NSData *data = [NSData dataWithContentsOfFile:filePath];
    id json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&err];
//    MKeyOrderModel * country = [[MKeyOrderModel alloc] initWithDictionary:json error:&err];
    
    MJKeyOrderModel *country = [MJKeyOrderModel mj_objectWithKeyValues:json];
    NSLog(@"%@",country);
}
//设置下划线自动转驼峰
- (void)getMUnderLineModel
{
//    {
//        "order_id" = 104;
//        "order_price" = "12.95";
//        "order_product" = "Product#1";
//    }
    NSError* err = nil;
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"MUnderLineModel" ofType:@"js"];
    NSData *data = [NSData dataWithContentsOfFile:filePath];
    id json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&err];
    MUnderLineModel * country = [[MUnderLineModel alloc] initWithDictionary:json error:&err];
    NSLog(@"%@",country);
}
//自定义数据的转换
- (void)getMDefineModel
{
    NSError* err = nil;
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"MDefineModel" ofType:@"js"];
    NSData *data = [NSData dataWithContentsOfFile:filePath];
    id json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&err];
//    MDefineModel * country = [[MDefineModel alloc] initWithDictionary:json error:&err];
//     NSLog(@"%@",country);
}
//自定义JSON校验
- (void)getMVaildModel
{
    NSError* err = nil;
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"coutryModel" ofType:@"js"];
    NSData *data = [NSData dataWithContentsOfFile:filePath];
    id json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&err];
    MVaildModel * country = [[MVaildModel alloc] initWithDictionary:json error:&err];
    NSLog(@"%@",country);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
