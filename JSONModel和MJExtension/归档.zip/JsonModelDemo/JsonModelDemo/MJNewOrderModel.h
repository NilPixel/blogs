//
//  MJNewOrderModel.h
//  JsonModelDemo
//
//  Created by Apple on 16/10/18.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MJProducts;
@interface MJNewOrderModel : NSObject

@property (nonatomic, assign) float total_price;

@property (nonatomic, assign) NSInteger order_id;

@property (nonatomic, strong) NSArray<MJProducts *> *products;


@end
@interface MJProducts : NSObject

@property (nonatomic, copy) NSString *productId;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, assign) float price;

@end

