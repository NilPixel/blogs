//
//  MCountryModel.m
//  JsonModelDemo
//
//  Created by Apple on 16/9/28.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import "MCountryModel.h"

@implementation MCountryModel

//- (void)encodeWithCoder:(NSCoder *)aCoder
//{
//    [aCoder encodeObject:_countryId forKey:@"countryId"];
//    [aCoder encodeObject:_country forKey:@"country"];
//    [aCoder encodeObject:_dialCode forKey:@"dialCode"];
//
//}
//
//- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder
//{
//    MCountryModel * msg = [MCountryModel new];
//    msg.countryId = [aDecoder decodeObjectForKey:@"countryId"];
//    msg.country = [aDecoder decodeObjectForKey:@"country"];
//    msg.dialCode = [aDecoder decodeObjectForKey:@"dialCode"];
//    return msg;
//}

@end
