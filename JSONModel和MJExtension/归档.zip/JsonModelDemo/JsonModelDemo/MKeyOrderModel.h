//
//  MKeyOrderModel.h
//  JsonModelDemo
//
//  Created by Apple on 16/9/28.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import "JSONModel.h"

@interface MKeyOrderModel : JSONModel

@property (assign, nonatomic) int orderId;

@property (assign, nonatomic) float price;

@property (strong, nonatomic) NSString* productName;

@end
