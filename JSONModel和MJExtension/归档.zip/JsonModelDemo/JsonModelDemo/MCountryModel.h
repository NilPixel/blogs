//
//  MCountryModel.h
//  JsonModelDemo
//
//  Created by Apple on 16/9/28.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import "JSONModel.h"

@interface MCountryModel : JSONModel<NSCoding>

@property (nonatomic, copy) NSString *countryId;

@property (nonatomic, copy) NSString *country;

@property (nonatomic, assign) NSInteger dialCode;


@end
