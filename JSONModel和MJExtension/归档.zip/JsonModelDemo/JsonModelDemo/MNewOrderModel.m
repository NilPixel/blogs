//
//  MNewOrderModel.m
//  JsonModelDemo
//
//  Created by Apple on 16/9/28.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import "MNewOrderModel.h"

@implementation MNewOrderModel


+ (NSDictionary *)objectClassInArray{
    return @{@"products" : [Products class]};
}
@end

//@implementation Product
//
//@end


@implementation Products

@end


