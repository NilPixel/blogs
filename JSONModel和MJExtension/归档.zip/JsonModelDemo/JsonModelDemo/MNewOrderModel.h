//
//  MNewOrderModel.h
//  JsonModelDemo
//
//  Created by Apple on 16/9/28.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import "JSONModel.h"

//@protocol  Product
//
//@end
//
@class Products;
@interface MNewOrderModel : JSONModel
@property (nonatomic, assign) NSInteger total_price;

@property (nonatomic, assign) NSInteger order_id;

@property (nonatomic, strong) NSArray<Products *> *products;


//
//@property (nonatomic, assign) float total_price;
//
//@property (nonatomic, assign) NSInteger order_id;
//
//@property (nonatomic, strong) NSDictionary<Product> *products;
//
//@end
//@interface Product : JSONModel
//
//@property (nonatomic, copy) NSString *productId;
//
//@property (nonatomic, copy) NSString *name;
//
//@property (nonatomic, assign) float price;

@end

@interface Products : NSObject

@property (nonatomic, copy) NSString *name;

@property (nonatomic, assign) NSInteger price;

@property (nonatomic, copy) NSString *productId;

@end

