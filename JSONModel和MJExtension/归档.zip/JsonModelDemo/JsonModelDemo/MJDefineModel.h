//
//  MJDefineModel.h
//  JsonModelDemo
//
//  Created by Apple on 16/10/21.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MJDefineModel : NSObject

@property (nonatomic, strong) NSDate *date;

@property (nonatomic, strong) NSURL *testUrl;

@end
