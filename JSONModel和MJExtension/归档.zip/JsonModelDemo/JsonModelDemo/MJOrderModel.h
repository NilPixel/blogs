//
//  MJOrderModel.h
//  JsonModelDemo
//
//  Created by Apple on 16/10/18.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MJProduct;
@interface MJOrderModel : NSObject

@property (nonatomic, copy) NSString * total_price;

@property (nonatomic, assign) NSInteger order_id;

@property (nonatomic, strong) MJProduct *product;

@end
@interface MJProduct : NSObject

@property (nonatomic, copy) NSString *productId;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, assign) float price;

@end

